<?php $__env->startSection('title', trans('m.breeding')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.breeding'); ?> <small><?php echo e($breeding->cow->name); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-lg-4">
        <?php echo $__env->make('box.cow.info', ['cow' => $breeding->cow], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-6 col-lg-4">
        <?php echo $__env->make('box.breeding.info', ['edit' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('breeding.show', $breeding); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>