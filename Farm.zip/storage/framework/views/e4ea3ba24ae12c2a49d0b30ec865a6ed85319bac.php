<?php $__env->startSection('title', trans('m.treatment')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.treatment'); ?> <small><?php echo e($treatment->cow->name); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo app('translator')->get('m.update'); ?></h3>
            </div>
            <?php echo $__env->make('treatment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('treatment.show', $treatment); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>