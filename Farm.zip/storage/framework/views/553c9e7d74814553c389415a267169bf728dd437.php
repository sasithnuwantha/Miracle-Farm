<div class="box box-primary">
    <div class="box-header">
        <h3 class="box-title"><?php echo app('translator')->get('m.info', ['name' => trans('m.breeding')]); ?></h3>
        <?php if(isset($edit) && $edit): ?>
        <a href="<?php echo e(route('breeding.edit', ['breeding' => $breeding])); ?>" class="pull-right"><i class="fa fa-edit"></i> <?php echo app('translator')->get('m.edit'); ?></a>
        <?php endif; ?>
    </div>
    <div class="box-body">
        <dl class="dl-horizontal">
            <dt><?php echo app('translator')->get('m.name'); ?></dt>
            <dd><?php echo e($breeding->cow->name); ?></dd>
            <dt><?php echo app('translator')->get('m.breeder'); ?></dt>
            <dd><?php echo e($breeding->breeder->name); ?></dd>
            <dt><?php echo app('translator')->get('m.serviceDate'); ?></dt>
            <dd><?php echo with($breeding->service_date) ? with($breeding->service_date)->format('d/m/Y') : null ?></dd>
            <dt><?php echo app('translator')->get('m.inCharge'); ?></dt>
            <dd><?php echo e(isset($breeding->in_charge) ? $breeding->in_charge : null); ?></dd>
            <dt><?php echo app('translator')->get('m.status'); ?></dt>
            <dd><?php echo e($breeding->getStatusName()); ?></dd>
            <dt><?php echo app('translator')->get('m.calvingDate'); ?></dt>
            <dd><?php echo with($breeding->getCalvingDate()) ? with($breeding->getCalvingDate())->format('d/m/Y') : null ?></dd>
            <dt><?php echo app('translator')->get('m.dryDate'); ?></dt>
            <dd><?php echo with($breeding->getDryDate()) ? with($breeding->getDryDate())->format('d/m/Y') : null ?></dd>
        </dl>
    </div>
    <?php if(isset($edit) && $edit): ?>
    <div class="box-footer">

        <?php echo e(Form::bsErrors($errors)); ?>


        <?php foreach($breeding->getPossibleStatus() as $status): ?>
        <button type="button" class="btn <?php echo e($status['btn']); ?> btn-block btn-lg" data-toggle="modal" data-target="#breeding_<?php echo e($breeding->id); ?><?php echo e($status['status']); ?>">
            <i class="fa <?php echo e($status['icon']); ?>"></i> <?php echo e($status['name']); ?>

        </button>
        <?php endforeach; ?>

        <?php foreach($breeding->getPossibleStatus() as $status): ?>
        <div class="modal fade" id="breeding_<?php echo e($breeding->id); ?><?php echo e($status['status']); ?>" tabindex="-1" role="dialog" aria-labelledby="breeding">
            <?php echo e(Form::open(['url' => route('breeding.update.status', ['breeding' => $breeding, 'status' => $status['status']]), 'method' => 'put', 'class' => 'form-inline'])); ?>

            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title"><?php echo app('translator')->get('m.changeBreedingStatus'); ?></h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group" style="font-weight: normal;">
                            <?php echo app('translator')->get('m.areYouSureToChangeStatusTo'); ?> <?php echo e($status['name']); ?>

                            <?php if( in_array($status['status'], $breeding->calvingStatus) ): ?>
                            <?php echo app('translator')->get('m.on'); ?>
                            <div class="input-group">
                                <?php echo e(Form::date('date', date('Y-m-d'), ['class' => 'form-control'])); ?>

                            </div>
                            <?php endif; ?>
                            ?
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> <?php echo app('translator')->get('m.cancel'); ?></button>
                        <button type="submit" class="btn <?php echo e($status['btn']); ?>">
                            <i class="fa <?php echo e($status['icon']); ?>"></i> <?php echo e($status['name']); ?>

                        </button>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
