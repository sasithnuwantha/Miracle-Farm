<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo app('translator')->get('m.info', ['name' => trans('m.treatment')]); ?></h3>
        <?php if(isset($edit) && $edit): ?>
        <a href="<?php echo e(route('treatment.edit', ['treatment' => $treatment])); ?>" class="pull-right"><i class="fa fa-edit"></i> <?php echo app('translator')->get('m.edit'); ?></a>
        <?php endif; ?>
    </div>
    <div class="box-body">
        <dl class="dl-horizontal">
            <dt><?php echo app('translator')->get('m.cow'); ?></dt>
            <dd><?php echo e($treatment->cow->name); ?></dd>
            <dt><?php echo app('translator')->get('m.date'); ?></dt>
            <dd><?php echo e($treatment->date ? $treatment->date->format('d/m/Y') : null); ?></dd>
            <dt><?php echo app('translator')->get('m.type'); ?></dt>
            <dd><?php echo e($treatment->getTypeList()[$treatment->type]); ?></dd>
            <dt><?php echo app('translator')->get('m.summary'); ?></dt>
            <dd><?php echo e($treatment->summary); ?></dd>
            <dt><?php echo app('translator')->get('m.inCharge'); ?></dt>
            <dd><?php echo e($treatment->in_charge); ?></dd>
            <dt><?php echo app('translator')->get('m.cost'); ?></dt>
            <dd><?php echo e($treatment->cost ?: null); ?></dd>
            <dt><?php echo app('translator')->get('m.done'); ?></dt>
            <dd><?php echo e($treatment->done ?: null); ?></dd>
        </dl>
    </div>
</div>