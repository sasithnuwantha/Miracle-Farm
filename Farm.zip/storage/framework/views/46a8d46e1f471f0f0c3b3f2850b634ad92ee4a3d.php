<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Miracle Farm | <?php echo $__env->yieldContent('title'); ?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url(elixir("css/all.css"))); ?>">
  <link rel="manifest" href="<?php echo e(url('manifest.json')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(url('images/launcher-icon-1x.png')); ?>">
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="<?php echo e(url('/')); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>M</b>F</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Miracle</b>Farm</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

          <?php if( $user = Auth::user() ): ?>
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(url('images/user.png')); ?>" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo e($user->name); ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="<?php echo e(url('images/user.png')); ?>" class="img-circle" alt="User Image">

                <p><?php echo e($user->name); ?></p>
              </li>
              <li class="user-body">
                <div class="pull-right">
                  <a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <section class="sidebar">

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        <?php /* <li class="header">HEADER</li> */ ?>
        <!-- Optionally, you can add icons to the links -->
        <li><a href="<?php echo e(route('cow.index')); ?>"><i class="fa fa-link"></i> <span><?php echo app('translator')->get('m.cow'); ?></span></a></li>
        <li><a href="<?php echo e(route('breeding.index')); ?>"><i class="fa fa-link"></i> <span><?php echo app('translator')->get('m.breeding'); ?></span></a></li>
        <li><a href="<?php echo e(route('treatment.index')); ?>"><i class="fa fa-link"></i> <span><?php echo app('translator')->get('m.treatment'); ?></span></a></li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php $__env->startSection('header'); ?>
          Page Header
          <small>Optional description</small>
        <?php echo $__env->yieldSection(); ?>
      </h1>
      <?php echo $__env->yieldContent('breadcrumbs'); ?>
    </section>

    <!-- Main content -->
    <section class="content">

      <?php echo $__env->yieldContent('content'); ?>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <strong>Copyright &copy; 2018 <a href="#">MiracleFarm</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url(elixir("js/all.js"))); ?>"></script>
<?php echo $__env->yieldSection(); ?>
</body>
</html>