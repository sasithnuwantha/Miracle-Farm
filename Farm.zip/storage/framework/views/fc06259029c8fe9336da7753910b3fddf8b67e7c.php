<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <?php echo e(Html::ul($errors->all(), ['class' => 'list-unstyled'])); ?>

</div>
<?php endif; ?>