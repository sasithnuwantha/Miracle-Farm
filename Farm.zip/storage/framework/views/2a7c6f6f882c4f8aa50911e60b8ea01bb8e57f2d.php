<?php $__env->startSection('title', trans('m.breeding')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.breeding'); ?> <small><?php echo app('translator')->get('m.list'); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-2">
        <a class="btn btn-primary btn-block" href="<?php echo e(route('breeding.create')); ?>"><i class="fa fa-plus"></i> <?php echo app('translator')->get('m.create'); ?></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <?php echo $__env->make('box.breeding.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('breeding.index'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>