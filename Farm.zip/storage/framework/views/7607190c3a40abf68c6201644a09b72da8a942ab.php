<?php if($cow->exists): ?>
<?php echo e(Form::open(['url' => route('cow.update', ['cow' => $cow]), 'method' => 'put', 'files' => true])); ?>

<?php else: ?>
<?php echo e(Form::open(['url' => route('cow.store'), 'files' => true])); ?>

<?php endif; ?>

<div class="box-body">

    <div class="form-group">
        <?php echo e(Form::label('name', trans('m.name'))); ?>

        <?php echo e(Form::text('name', $cow->name, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('serial', trans('m.serial'))); ?>

        <?php echo e(Form::text('serial', $cow->serial, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('birthdate', trans('m.birthdate'))); ?>

        <?php echo e(Form::date('birthdate', $cow->birthdate, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('herd', trans('m.herd'))); ?>

        <?php echo e(Form::select('herd_id', \App\Herd::all()->lists('name', 'id'), $cow->herd_id, ['class' => 'form-control', 'placeholder' => 'Please Select Herd'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('breeder', trans('m.breeder'))); ?>

        <?php echo e(Form::select('breeder_id', \App\Breeder::all()->lists('name', 'id'), $cow->breeder_id, ['class' => 'form-control select2-tags', 'data-placeholder' => 'Please Select Breeder', 'placeholder' => ''])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('mother', trans('m.mother'))); ?>

        <?php echo e(Form::select('mother_id', \App\Cow::where('id', '<>', $cow->id)->get()->lists('name', 'id'), $cow->mother_id, ['class' => 'form-control select2', 'data-placeholder' => 'Please Select Mother', 'placeholder' => ''])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('images[]', trans('m.images'))); ?>

        <?php echo e(Form::file('images[]', ['multiple' => 'multiple'])); ?>

    </div>

</div>

<div class="box-footer">

    <?php echo e(Form::bsErrors($errors)); ?>

    
    <?php if($cow->exists): ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.save'); ?></button>
    <button type="button" class="btn btn-link pull-right" data-toggle="modal" data-target="#delete-modal"><i class="fa fa-trash-o"></i> <?php echo app('translator')->get('m.delete'); ?></button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.create'); ?></button>
    <?php endif; ?>
</div>

<?php echo e(Form::close()); ?>


<?php echo e(Form::bsModalDelete(route('cow.destroy', ['cow' => $cow]), 'delete-modal', trans('m.delete')." {$cow->name}", trans('m.areYouSureToDelete', ['name' => $cow->name]))); ?>