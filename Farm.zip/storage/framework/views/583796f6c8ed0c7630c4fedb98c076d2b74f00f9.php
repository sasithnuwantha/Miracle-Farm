<?php $__env->startSection('title', trans('m.treatment')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.treatment'); ?> <small><?php echo app('translator')->get('m.list'); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-2">
        <a class="btn btn-primary btn-block" href="<?php echo e(route('treatment.create')); ?>"><i class="fa fa-plus"></i> <?php echo app('translator')->get('m.create'); ?></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo app('translator')->get('m.treatment'); ?></h3>
            </div>
            <div class="box-body">
                <table class="table table-hover no-wrap" id=<?php echo e($id = uniqid()); ?>></table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('treatment.index'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

@parent

<script>
    $(document).ready(function() {
        var dataSet = <?php echo $treatments->map(function($treatment, $index) {
                return [
                    link_to_route('treatment.show', $treatment->cow->name, ['treatment' => $treatment])->toHtml(),
                    $treatment->date ? $treatment->date->format('d/m/Y') : null,
                    $treatment->getTypeList()[$treatment->type],
                    $treatment->summary,
                    $treatment->in_charge,
                    $treatment->cost ?: null,
                    $treatment->done ?: null,
                ];
            }); ?>;

        var table = $('#<?php echo e($id); ?>').DataTable({
            data: dataSet,
            ordering: false,
            responsive: true,
            columns: [
                { title: "<?php echo app('translator')->get('m.cow'); ?>"},
                { title: "<?php echo app('translator')->get('m.date'); ?>"},
                { title: "<?php echo app('translator')->get('m.type'); ?>"},
                { title: "<?php echo app('translator')->get('m.summary'); ?>"},
                { title: "<?php echo app('translator')->get('m.inCharge'); ?>"},
                { title: "<?php echo app('translator')->get('m.cost'); ?>"},
                { title: "<?php echo app('translator')->get('m.done'); ?>"}
            ],
            columnDefs: [
                { type: 'date-uk', targets: 1 }
            ]
        });

        $(window).resize(function() {
            table
            .columns.adjust()
            .responsive.recalc();
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>