<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="delete">
    <div class="modal-dialog" role="document">
        <?php echo e(Form::open(['url' => $url, 'method' => 'delete'])); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="delete"><?php echo e(isset($header) ? $header : trans('m.delete')); ?></h4>
            </div>
            <div class="modal-body">
                <?php echo e(isset($body) ? $body : trans('m.areYouSureToDelete', ['name' => ''])); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> <?php echo app('translator')->get('m.cancel'); ?></button>
                <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o"></i> <?php echo app('translator')->get('m.delete'); ?></button>
            </div>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>