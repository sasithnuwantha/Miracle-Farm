<?php if( $breeding->exists ): ?>
<?php echo e(Form::open(['url' => route('breeding.update', ['breeding' => $breeding]), 'method' => 'put'])); ?>

<?php else: ?>
<?php echo e(Form::open(['url' => route('breeding.store')])); ?>

<?php endif; ?>

<div class="box-body">

    <div class="form-group">
        <?php echo e(Form::label('cow_id', trans('m.cow'))); ?>

        <?php echo e(Form::select('cow_id', \App\Cow::all()->lists('name', 'id'), $breeding->cow_id, ['class' => 'form-control select2', 'data-placeholder' => 'Please Cow', 'placeholder' => ''])); ?>                    
    </div>

    <div class="form-group">
        <?php echo e(Form::label('breeder_id', trans('m.breeder'))); ?>

        <?php echo e(Form::select('breeder_id', \App\Breeder::all()->lists('name', 'id'), $breeding->breeder_id, ['class' => 'form-control select2-tags', 'data-placeholder' => 'Please Breeder', 'placeholder' => ''])); ?>                    
    </div>

    <div class="form-group">
        <?php echo e(Form::label('service_date', trans('m.serviceDate'))); ?>

        <?php echo e(Form::date('service_date', $breeding->service_date, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('in_charge', trans('m.inCharge'))); ?>

        <?php echo e(Form::text('in_charge', $breeding->in_charge, ['class' => 'form-control'])); ?>

    </div>

    <?php if( $breeding->exists ): ?>
    
    <div class="form-group">
        <?php echo e(Form::label('status', trans('m.status'))); ?>

        <?php echo e(Form::select('status', array_pluck($breeding->getStatusList(), 'name', 'status') ,$breeding->status, ['class' => 'form-control'])); ?>

    </div>
    
    <div class="form-group">
        <?php echo e(Form::label('calving_date', trans('m.calvingDate'))); ?>

        <?php echo e(Form::date('calving_date', $breeding->calving_date, ['class' => 'form-control'])); ?>

    </div>
    
    <div class="form-group">
        <?php echo e(Form::label('dry_date', trans('m.dryDate'))); ?>

        <?php echo e(Form::date('dry_date', $breeding->dry_date, ['class' => 'form-control'])); ?>

    </div>

    <?php else: ?>

    <?php echo e(Form::hidden('status', 'UNCONFIRM')); ?>


        <?php if(isset($treatment)): ?>
        <div class="checkbox icheck">
            <label>
                <?php echo e(Form::checkbox('treatment_id', $treatment->id, true)); ?>

                <?php echo app('translator')->get('m.createForTreatmentAndDirectBack'); ?>
            </label>
        </div>
        <?php endif; ?>

        <div class="checkbox icheck">
            <label>
                <?php echo e(Form::checkbox('with_treatments', true, true)); ?>

                <?php echo app('translator')->get('m.createTreatmentsAsPossible'); ?>
            </label>
        </div>
    
    <?php endif; ?>
</div>

<div class="box-footer">

    <?php echo e(Form::bsErrors($errors)); ?>

    
    <?php if($breeding->exists): ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.save'); ?></button>
    <button type="button" class="btn btn-link pull-right" data-toggle="modal" data-target="#delete-modal"><i class="fa fa-trash-o"></i> <?php echo app('translator')->get('m.delete'); ?></button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.create'); ?></button>
    <?php endif; ?>
</div>

<?php echo e(Form::close()); ?>


<?php echo e(Form::bsModalDelete(route('breeding.destroy', ['breeding' => $breeding]), 'delete-modal')); ?>