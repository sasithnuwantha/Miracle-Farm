<?php $__env->startSection('title', trans('m.dashboard')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.dashboard'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <?php echo $__env->make('box.dashboard.herds', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-8">
        <?php echo $__env->make('box.dashboard.incomingTreatments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('box.dashboard.pregnantBreedings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('home'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>