<?php $__env->startSection('title', 'Treatment'); ?>

<?php $__env->startSection('header'); ?>
Treatment <small><?php echo e($treatment->cow->name); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-lg-4">
        <?php echo $__env->make('box.cow.info', ['cow' => $treatment->cow], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-6 col-lg-4">
        <?php echo $__env->make('box.treatment.info', ['edit' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php if( in_array($treatment->type, ['PREGNANCY_DIAGNOSE', 'BREEDING']) ): ?>
    <div class="col-md-6 col-lg-4">
        <?php echo $__env->make('box.treatment.breeding', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('treatment.show', $treatment); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>