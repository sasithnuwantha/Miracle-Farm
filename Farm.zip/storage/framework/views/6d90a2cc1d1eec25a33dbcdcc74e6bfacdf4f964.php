<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo app('translator')->get('m.info', ['name' => trans('m.cow')]); ?></h3>
        <?php if(isset($edit) && $edit): ?>
        <a href="<?php echo e(route('cow.edit', ['cow' => $cow])); ?>" class="pull-right"><i class="fa fa-edit"></i> <?php echo app('translator')->get('m.edit'); ?></a>
        <?php endif; ?>
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="thumbnail">
                    <img src="<?php echo e($cow->defaultImageUrl()); ?>">
                </div>
            </div>
        </div>
        <dl class="dl-horizontal">
            <dt><?php echo app('translator')->get('m.name'); ?></dt>
            <dd><?php echo e($cow->name); ?></dd>
            <dt><?php echo app('translator')->get('m.birthdate'); ?></dt>
            <dd><?php echo with($cow->birthdate) ? with($cow->birthdate)->format('d/m/Y') : null ?></dd>
            <dt><?php echo app('translator')->get('m.herd'); ?></dt>
            <dd><?php echo e(isset($cow->herd->name) ? $cow->herd->name : null); ?></dd>
            <dt><?php echo app('translator')->get('m.breeder'); ?></dt>
            <dd><?php echo e(isset($cow->breeder->name) ? $cow->breeder->name : null); ?></dd>
            <dt><?php echo app('translator')->get('m.mother'); ?></dt>
            <dd><?php echo e(isset($cow->mother->name) ? $cow->mother->name : null); ?></dd>
        </dl>
    </div>
</div>