<?php $__env->startSection('title', trans('m.breeding')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.breeding'); ?> <small><?php echo e($breeding->cow->name); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo app('translator')->get('m.update'); ?></h3>
            </div>
            
            <?php echo $__env->make('breeding.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('breeding.show', $breeding); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>