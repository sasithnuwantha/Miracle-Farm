<?php $__env->startSection('title', trans('m.cow')); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('translator')->get('m.cow'); ?> <small><?php echo app('translator')->get('m.list'); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-2">
        <a class="btn btn-primary btn-block" href="<?php echo e(route('cow.create')); ?>"><i class="fa fa-plus"></i> <?php echo app('translator')->get('m.create'); ?></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo app('translator')->get('m.cow'); ?></h3>
            </div>
            <div class="box-body">
                <table class="table table-hover no-wrap" id=<?php echo e($id = uniqid()); ?>></table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('cow.index'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

@parent

<script>
    $(document).ready(function() {
        var dataSet = <?php echo $cows->map(function($cow, $index) {
                return [
                    link_to_route('cow.show', $cow->name, ['cow' => $cow])->toHtml(),
                    $cow->serial,
                    $cow->birthdate ? $cow->birthdate->format('d/m/Y') : null,
                    $cow->herd ? $cow->herd->name : null,
                    $cow->breeder ? $cow->breeder->name : null,
                    $cow->mother ? $cow->mother->name : null,
                ];
            }); ?>;

        var table = $('#<?php echo e($id); ?>').DataTable({
            data: dataSet,
            responsive: true,
            ordering: false,
            columns: [
                { title: "<?php echo app('translator')->get('m.name'); ?>"},
                { title: "<?php echo app('translator')->get('m.serial'); ?>"},
                { title: "<?php echo app('translator')->get('m.birthdate'); ?>"},
                { title: "<?php echo app('translator')->get('m.herd'); ?>"},
                { title: "<?php echo app('translator')->get('m.breeder'); ?>"},
                { title: "<?php echo app('translator')->get('m.mother'); ?>"}
            ],
            columnDefs: [
                { type: 'date-uk', targets: 2 }
            ]
        });

        $(window).resize(function() {
            table
            .columns.adjust()
            .responsive.recalc();
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>