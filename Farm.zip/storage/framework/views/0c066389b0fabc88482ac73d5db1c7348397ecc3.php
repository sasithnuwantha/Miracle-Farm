<?php if($treatment->exists): ?>
<?php echo e(Form::open(['url' => route('treatment.update', ['treatment' => $treatment]), 'method' => 'put'])); ?>

<?php else: ?>
<?php echo e(Form::open(['url' => route('treatment.store')])); ?>

<?php endif; ?>

<div class="box-body">

    <div class="form-group">
        <?php echo e(Form::label('cow_id', trans('m.cow'))); ?>

        <?php echo e(Form::select('cow_id', \App\Cow::all()->lists('name', 'id'), $treatment->cow_id, ['class' => 'form-control select2', 'data-placeholder' => 'Please Cow', 'placeholder' => '', 'disable' => true])); ?>                    
    </div>

    <div class="form-group">
        <?php echo e(Form::label('date', trans('m.date'))); ?>

        <?php echo e(Form::date('date', $treatment->date ?: date('Y-m-d'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('type', trans('m.type'))); ?>

        <?php echo e(Form::select('type', $treatment->getTypeList(), $treatment->type, ['class' => 'form-control', 'placeholder' => ''])); ?>                    
    </div>

    <div class="form-group">
        <?php echo e(Form::label('summary', trans('m.summary'))); ?>

        <?php echo e(Form::textarea('summary', $treatment->summary, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('in_charge', trans('m.inCharge'))); ?>

        <?php echo e(Form::text('in_charge', $treatment->in_charge, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('cost', trans('m.cost'))); ?>

        <?php echo e(Form::number('cost', $treatment->cost, ['class' => 'form-control'])); ?>

    </div>

    <div class="checkbox icheck">
        <label>
            <?php echo e(Form::checkbox('done', 1, $treatment->done)); ?> <?php echo app('translator')->get('m.done'); ?>
        </label>
    </div>

</div>

<div class="box-footer">

    <?php echo e(Form::bsErrors($errors)); ?>

    
    <?php if($treatment->exists): ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.save'); ?></button>
    <button type="button" class="btn btn-link pull-right" data-toggle="modal" data-target="#delete-modal"><i class="fa fa-trash-o"></i> <?php echo app('translator')->get('m.delete'); ?></button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-floppy-o"></i> <?php echo app('translator')->get('m.create'); ?></button>
    <?php endif; ?>
</div>

<?php echo e(Form::close()); ?>


<?php echo e(Form::bsModalDelete(route('treatment.destroy', ['treatment' => $treatment]), 'delete-modal')); ?>

