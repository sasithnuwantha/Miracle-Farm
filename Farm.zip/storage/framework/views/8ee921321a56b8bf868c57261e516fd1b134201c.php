<?php if( $treatment->treatable ): ?>
<?php echo $__env->make( 'box.breeding.info', ['breeding' => $treatment->treatable, 'edit' => $treatment->treatable->status == 'UNCONFIRM' && $treatment->type == 'PREGNANCY_DIAGNOSE'] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<?php echo e(Form::open(['url' => route('treatment.update.treatable', ['treatment' => $treatment]), 'method' => 'put'])); ?>

<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo app('translator')->get('m.breeding'); ?></h3>
    </div>
    <div class="box-body">
        <a href="<?php echo e(route('breeding.create', ['treatment_id' => $treatment->id])); ?>" class="btn btn-primary btn-block btn-lg">
            <i class="fa fa-plus"></i> <?php echo app('translator')->get('m.create'); ?>
        </a>
        <hr>
        <div class="form-group">
            <?php echo e(Form::select('treatable_id', $treatment->cow->breedings()->orderBy('service_date', 'desc')->get()->lists('full_name', 'id'), $treatment->treatable_id, ['class' => 'form-control', 'placeholder' => ''])); ?>

            <?php echo e(Form::hidden('treatable_type', App\Breeding::class)); ?>

        </div>
        <button class="btn btn-primary btn-block btn-lg"><i class="fa fa-check"></i> <?php echo app('translator')->get('m.select'); ?></button>
    </div>
</div>
<?php echo e(Form::close()); ?>

<?php endif; ?>