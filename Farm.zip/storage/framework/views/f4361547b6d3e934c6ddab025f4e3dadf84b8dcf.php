<div class="box">
    <div class="box-header">
        <h3 class="box-title"><?php echo app('translator')->get('m.breeding'); ?></h3>
    </div>
    <div class="box-body">
        <table class="table table-hover no-wrap" id=<?php echo e($id = uniqid()); ?>></table>
    </div>
</div>

<?php $__env->startSection('script'); ?>

@parent

<script>
    $(document).ready(function() {
        var dataSet = <?php echo $breedings->map(function($breeding, $index) {
                return [
                link_to_route('breeding.show', $breeding->cow->name, ['breeding' => $breeding])->toHtml(),
                $breeding->breeder->name,
                $breeding->service_date ? $breeding->service_date->format('d/m/Y') : null,
                $breeding->in_charge,
                $breeding->status,
                $breeding->getCalvingDate() ? $breeding->getCalvingDate()->format('d/m/Y') : null,
                $breeding->getDryDate() ? $breeding->getDryDate()->format('d/m/Y') : null,
                ];
            }); ?>;

        var table = $('#<?php echo e($id); ?>').DataTable({
            data: dataSet,
            ordering: false,
            responsive: true,
            columns: [
                { title: "<?php echo app('translator')->get('m.name'); ?>"},
                { title: "<?php echo app('translator')->get('m.breeder'); ?>"},
                { title: "<?php echo app('translator')->get('m.serviceDate'); ?>"},
                { title: "<?php echo app('translator')->get('m.inCharge'); ?>"},
                { title: "<?php echo app('translator')->get('m.status'); ?>"},
                { title: "<?php echo app('translator')->get('m.calvingDate'); ?>"},
                { title: "<?php echo app('translator')->get('m.dryDate'); ?>"}
            ],
            columnDefs: [
                { type: 'date-uk', targets: 2 },
                { type: 'date-uk', targets: 5 },
                { type: 'date-uk', targets: 6 }
            ]
        });

        $(window).resize(function() {
            table
            .columns.adjust()
            .responsive.recalc();
        });
    });
</script>

<?php $__env->stopSection(); ?>